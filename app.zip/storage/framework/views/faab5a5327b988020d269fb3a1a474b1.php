<?php $__env->startSection('content'); ?>


<!-- Content Start -->
<div class="content">
    <!-- Navbar Start -->
    <nav class="navbar navbar-expand bg-secondary navbar-dark sticky-top px-4 py-0">
        <a href="<?php echo e(route('home')); ?>" class="navbar-brand d-flex d-lg-none me-4">
            <h2 class="text-primary mb-0"><i class="fa fa-user-edit"></i></h2>
        </a>
        <a href="#" class="sidebar-toggler flex-shrink-0">
            <i class="fa fa-bars"></i>
        </a>
        <form class="d-none d-md-flex ms-4">
            <input class="form-control bg-dark border-0" type="search" placeholder="Search">
        </form>
        <div class="navbar-nav align-items-center ms-auto">
        </div>
    </nav>
    <!-- Navbar End -->


    <!-- Table Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4 ">
            <div class="col-sm-12 col-xl-6">
                <div class="bg-secondary rounded h-100 p-4">
                    <?php if(session()->has('msg')): ?>
                        <div class="alert alert-info">
                            <?php echo e(session()->get('msg')); ?>

                        </div>
                    <?php elseif(session()->has('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session()->get('error')); ?>

                        </div>
                    <?php endif; ?>
                    <h6 class="mb-4"><?php echo e(isset($edit) ? "Update Partner":"Add Partner"); ?></h6>
                    <form action="<?php echo e(isset($edit) ? route('updatePartners',['id'=>$partner->id]) : route('storePartners')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" name="name" class="form-control" id="name" value="<?php echo e(isset($edit) ? $partner->name:''); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Email address</label>
                            <input type="email" name="email" value="<?php echo e(isset($edit) ? $partner->email:''); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                            <div id="emailHelp" class="form-text">We'll never share your email with anyone else.
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Password</label>
                            <input type="password" name="password" value="<?php echo e(isset($edit) ? $partner->password:''); ?>" class="form-control" id="exampleInputPassword1">
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo e(isset($edit) ? "Update Partner":"Add Partner"); ?></button>
                    </form>
                </div>
            </div>
            <div class="col-sm-12 col-xl-6">
                <div class="bg-secondary rounded h-100 p-4 d-flex h-100 align-items-center">
                    <img class="img-fluid" src="<?php echo e(asset('partner.png')); ?>" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- Table End -->

    <!-- Content End -->


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BookingAppDashboard\resources\views/addPartners.blade.php ENDPATH**/ ?>