<?php $__env->startSection('content'); ?>


<!-- Content Start -->
<div class="content">
    <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- Table Start -->
    <div class="container-fluid pt-4 px-4">
        <!-- Step Start -->

        <div class="row mb-5">
            <div class="progress bg-transparent mb-1">
                <div class="progress-bar progress-bar-striped progress-bar-animated bg-success" role="progressbar" style="width: 3%" aria-valuemin="0" aria-valuemax="100"></div>
            </div>
            <div class="col-4">
                <div class="row">
                    <div class="6">
                        <a href="<?php echo e(route('bookings')); ?>" class="btn btn-warning">
                            <i class="fa fa-book"></i>
                            Booking
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="row">
                    <div class="6">
                        <a href="<?php echo e(isset($booking_id) ? route('passengers',['booking_id' => $booking_id]) : ''); ?>" class="btn btn-warning">
                            <i class="fa fa-user"></i>
                            Passengers
                        </a>
                    </div>
                </div>
            </div>
            <div class="col-4">
                <div class="row">
                    <div class="6">
                        <a href="<?php echo e(isset($booking_id) ? route('bookingDetail',['booking_id'=> $booking_id]) : ''); ?>" class="btn btn-warning">
                            <i class="fa fa-flag"></i>
                            Finalize
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Step End -->
        <div class="row g-4">
            <div class="col-12">
                <div class="bg-secondary rounded h-100 p-4">
                    <?php if(session()->has('msg')): ?>
                        <div class="alert alert-info">
                            <?php echo e(session()->get('msg')); ?>

                        </div>
                    <?php elseif(session()->has('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session()->get('error')); ?>

                        </div>
                    <?php endif; ?>
                    <h6 class="mb-4">Add Booking</h6>
                    <form action="<?php echo e(isset($edit) ? route('updateBooking',['id'=> $booking->id]) : route('storeBooking')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="booking_id" class="form-label">Booking ID</label>
                            <input type="text" name="booking_id" class="form-control" value="<?php echo e(isset($edit) ? $booking->booking_id:''); ?>" placeholder="Pre-booked booking id" id="booking_id">
                        </div>
                        <div class="mb-3">
                            <label for="destination" class="form-label">Drop Off</label>
                            <input type="text" name="destination" class="form-control" value="<?php echo e(isset($edit) ? $booking->destination:''); ?>" placeholder="City Center, train station. Etc. hotel or property" id="destination">
                        </div>
                        <div class="mb-3">
                            <label for="location" class="form-label">Pick Up</label>
                            <input type="text" name="location" class="form-control" value="<?php echo e(isset($edit) ? $booking->location:''); ?>" id="location">
                        </div>
                        <div class="mb-3">
                            <label for="passenger_nos" class="form-label">Passengers</label>
                            <input type="number" name="passenger_nos" class="form-control" value="<?php echo e(isset($edit) ? $booking->passenger_nos:''); ?>" id="passenger_nos">
                        </div>
                        <div class="mb-3">
                            <label for="pick_date_time" class="form-label">Pick Date Time</label>
                            <input type="datetime-local" name="pick_date_time" value="<?php echo e(isset($edit) ? $booking->pick_date_time:''); ?>" class="form-control" id="pick_date_time">
                        </div>
                        <div class="mb-3">
                            <label for="vehicle_type" class="form-label">Vehicle Type</label>
                            <select name="vehicle_type" class="form-select" id="vehicle_type">
                                <?php $__currentLoopData = $vehicleTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicleType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($vehicleType->type); ?>" <?php echo e(isset($booking) && $booking->vehicle_type == $vehicleType->type ? "selected":""); ?>><?php echo e($vehicleType->type); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="price" class="form-label">Price</label>
                            <div class="input-group mb-3">
                                <select name="currency" class="btn btn-warning">
                                    <option>Select one</option>
                                    <option value="EUR">EUR</option>
                                    <option value="DKK">DKK</option>
                                </select>
                                <input type="text" name="price" value="<?php echo e(isset($edit) ? $booking->price:''); ?>" class="form-control" id="price">
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="extras" class="form-label">Extras</label>
                            <div class="form-check">
                                <input class="form-check-input" name="extras['wheelchair']" type="checkbox" id="wheelchair">
                                <label class="form-check-label" for="wheelchair">
                                    wheelchair
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="extras['babyseat']" type="checkbox" id="babyseat">
                                <label class="form-check-label" for="babyseat">
                                    babyseat
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="extras['childseat']" type="checkbox" id="childseat">
                                <label class="form-check-label" for="childseat">
                                    childseat
                                </label>
                            </div>
                            
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo e(isset($edit) ? 'Update Booking':'Add Booking'); ?></button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Table End -->

    <!-- Content End -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BookingBackEnd\resources\views/add_booking.blade.php ENDPATH**/ ?>