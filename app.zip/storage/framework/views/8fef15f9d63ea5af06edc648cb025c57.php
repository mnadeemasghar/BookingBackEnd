<?php $__env->startSection('content'); ?>


<!-- Content Start -->
<div class="content">
    <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- Table Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded h-100 p-4">
            <?php if(session()->has('msg')): ?>
                <div class="alert alert-info">
                    <?php echo e(session()->get('msg')); ?>

                </div>
            <?php elseif(session()->has('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('error')); ?>

                </div>
            <?php endif; ?>
            <h6 class="mb-4"><?php echo e(isset($edit) ? "Update Vehicle":"Add Vehicle"); ?></h6>
            <form action="<?php echo e(isset($edit) ? route('updateVehicle',['id'=>$vehicle->id]) : route('storeVehicle')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="type" class="form-label">Type</label>
                    <input type="text" name="type" class="form-control" id="type" value="<?php echo e(isset($edit) ? $vehicle->type:''); ?>">
                </div>
                <button type="submit" class="btn btn-primary"><?php echo e(isset($edit) ? "Update Vehicle":"Add Vehicle"); ?></button>
            </form>
        </div>
    </div>
    <!-- Table End -->

    <!-- Content End -->


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BookingBackEnd\resources\views/addVehicle.blade.php ENDPATH**/ ?>