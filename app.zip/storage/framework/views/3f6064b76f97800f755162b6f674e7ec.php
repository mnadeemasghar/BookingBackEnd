<?php $__env->startSection('content'); ?>


<!-- Content Start -->
<div class="content">
    <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- Table Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4 ">
            <div class="col-sm-12 col-xl-6">
                <div class="bg-secondary rounded h-100 p-4">
                    <?php if(session()->has('msg')): ?>
                        <div class="alert alert-info">
                            <?php echo e(session()->get('msg')); ?>

                        </div>
                    <?php elseif(session()->has('error')): ?>
                        <div class="alert alert-danger">
                            <?php echo e(session()->get('error')); ?>

                        </div>
                    <?php endif; ?>
                    <h6 class="mb-4"><?php echo e(isset($edit) ? "Update Partner":"Add Partner"); ?></h6>
                    <form action="<?php echo e(isset($edit) ? route('updatePartners',['id'=>$partner->id]) : route('storePartners')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" name="name" class="form-control" id="name" value="<?php echo e(isset($edit) ? $partner->name:''); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" class="form-label">Email address</label>
                            <input type="email" name="email" value="<?php echo e(isset($edit) ? $partner->email:''); ?>" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
                            <div id="emailHelp" class="form-text">We'll never share your email with anyone else.
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputPassword1" class="form-label">Password</label>
                            <input type="password" name="password" value="<?php echo e(isset($edit) ? $partner->password:''); ?>" class="form-control" id="exampleInputPassword1">
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo e(isset($edit) ? "Update Partner":"Add Partner"); ?></button>
                    </form>
                </div>
            </div>
            <div class="col-sm-12 col-xl-6">
                <div class="bg-secondary rounded h-100 p-4 d-flex h-100 align-items-center">
                    <img class="img-fluid" src="<?php echo e(asset('partner.png')); ?>" alt="">
                </div>
            </div>
        </div>
    </div>
    <!-- Table End -->

    <!-- Content End -->


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BookingBackEnd\resources\views/addPartners.blade.php ENDPATH**/ ?>