<?php $__env->startSection('content'); ?>

    <!-- Content Start -->
    <div class="content">
        <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!-- Sale & Revenue Start -->
        <div class="container-fluid pt-4 px-4">
            <h1><?php echo e($role); ?> - Dashboard</h1>
            <div class="row g-4">
                <?php $__currentLoopData = $data['cards']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6 col-xl-3">
                        <div class="bg-secondary rounded d-flex align-items-center justify-content-between p-4">
                            <?php echo $card['card_icon']; ?>

                            <div class="ms-3">
                                <p class="mb-2"><?php echo e($card['card_title']); ?></p>
                                <h6 class="mb-0"><?php echo e($card['card_value']); ?></h6>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <!-- Sale & Revenue End -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BookingBackEnd\resources\views/home.blade.php ENDPATH**/ ?>