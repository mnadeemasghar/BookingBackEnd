<?php $__env->startSection('content'); ?>


<!-- Content Start -->
<div class="content">
    <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- Table Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded h-100 p-4">
            <?php if(session()->has('msg')): ?>
                <div class="alert alert-info">
                    <?php echo e(session()->get('msg')); ?>

                </div>
            <?php elseif(session()->has('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('error')); ?>

                </div>
            <?php endif; ?>
            <h6 class="mb-4">Assign Driver</h6>
            <form action="<?php echo e(route('assignDriverStore',['booking_id' => $booking->id])); ?> " method="POST">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="driver_id" class="form-label">Driver</label>
                    <select name="driver_id" class="form-control" id="driver_id">
                        <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($driver->available): ?>
                                <option value="<?php echo e($driver->id); ?>"><?php echo e($driver->id); ?> - <?php echo e($driver->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="price_driver" class="form-label">Driver Price</label>
                    <input type="text" name="price_driver" class="form-control" id="price_driver">
                </div>
                <button type="submit" class="btn btn-primary">Assign Driver</button>
            </form>
        </div>
    </div>
    <!-- Table End -->

    <!-- Content End -->


    <?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BookingBackEnd\resources\views/assignDriver.blade.php ENDPATH**/ ?>