<?php $__env->startSection('content'); ?>

    <!-- Content Start -->
    <div class="content">
        <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!-- Table Start -->
        <div class="container-fluid pt-4 px-4">
            <div class="row g-4">
                <div class="col-12">
                    <div class="bg-secondary rounded h-100 p-4">
                        <h6 class="mb-4">Partners Data</h6>
                        <a href="<?php echo e(route('addPartners')); ?>" class="btn btn-primary">Add Partner</a>
                        <div class="table-responsive">
                            <table class="table  table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Created At</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($partner->id); ?></th>
                                            <td><?php echo e($partner->name); ?></td>
                                            <td><?php echo e($partner->email); ?></td>
                                            <td><?php echo e($partner->created_at); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('editPartners',['id'=>$partner->id])); ?>"><i class="fa fa-edit"></i>Edit</a>
                                                |
                                                <a href="<?php echo e(route('deleteUsers',['id'=>$partner->id])); ?>"><i class="fa fa-trash"></i>Delete</a>
                                                |
                                                <a href="<?php echo e(route('viewUserLogs',['user_id'=>$partner->id])); ?>"> <i class="fa fa-file"></i>View Logs</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Table End -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BookingBackEnd\resources\views/partners.blade.php ENDPATH**/ ?>