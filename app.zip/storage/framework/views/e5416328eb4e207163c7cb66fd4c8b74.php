<?php $__env->startSection('content'); ?>


<!-- Content Start -->
<div class="content">
    <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- Table Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded h-100 p-4">
            <?php if(session()->has('msg')): ?>
                <div class="alert alert-info">
                    <?php echo e(session()->get('msg')); ?>

                </div>
            <?php elseif(session()->has('error')): ?>
                <div class="alert alert-danger">
                    <?php echo e(session()->get('error')); ?>

                </div>
            <?php endif; ?>
            <h6 class="mb-4">Customer not Shown</h6>
            <form action="<?php echo e(route('noshowBookingPost',['id' => $id])); ?> " method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="mb-3">
                    <label for="not_shown_img" class="form-label">Select Image</label>
                    <input type="file" name="not_shown_img" class="form-control" id="not_shown_img">
                    <input type="text" name="lat" id="lat" class="d-none">
                    <input type="text" name="lon" id="lon" class="d-none">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
            <p>Your current location is:</p>
            <p id="location"></p>
        </div>
    </div>
    <!-- Table End -->

    <!-- Content End -->


    <script>
        document.addEventListener("DOMContentLoaded", function () {
        getLocation();
        });
      function getLocation() {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(showPosition, showError);
        } else {
          alert("Geolocation is not supported by this browser.");
        }
      }

      function showPosition(position) {
        var latitude = position.coords.latitude;
        var longitude = position.coords.longitude;
        document.getElementById("location").innerHTML = "Latitude: " + latitude + "<br>Longitude: " + longitude;
        document.getElementById("lat").value = latitude;
        document.getElementById("lon").value = longitude;
      }

      function showError(error) {
        switch (error.code) {
          case error.PERMISSION_DENIED:
            alert("User denied the request for Geolocation.");
            break;
          case error.POSITION_UNAVAILABLE:
            alert("Location information is unavailable.");
            break;
          case error.TIMEOUT:
            alert("The request to get user location timed out.");
            break;
          case error.UNKNOWN_ERROR:
            alert("An unknown error occurred.");
            break;
        }
      }
    </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BookingBackEnd\resources\views/noshow.blade.php ENDPATH**/ ?>