<!-- Navbar Start -->
<nav class="navbar navbar-expand bg-secondary navbar-dark sticky-top px-4 py-0">
    <a href="<?php echo e(route('home')); ?>" class="navbar-brand d-flex d-lg-none me-4">
        <h2 class="text-primary mb-0"><i class="fa fa-user-edit"></i></h2>
    </a>
    <a href="#" class="sidebar-toggler flex-shrink-0">
        <i class="fa fa-bars"></i>
    </a>
    
    <div class="navbar-nav align-items-center ms-auto">
    </div>
</nav>
<!-- Navbar End -->
<?php /**PATH C:\laragon\www\BookingBackEnd\resources\views/navbar.blade.php ENDPATH**/ ?>