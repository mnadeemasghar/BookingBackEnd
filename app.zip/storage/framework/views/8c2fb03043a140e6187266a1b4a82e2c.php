<?php $__env->startSection('content'); ?>

    <!-- Content Start -->
    <div class="content">
        <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!-- Table Start -->
        <div class="container-fluid pt-4 px-4">
            <div class="row g-4">
                <div class="col-12">
                    <div class="bg-secondary rounded h-100 p-4">
                        <?php if(session()->has('msg')): ?>
                            <div class="alert alert-info">
                                <?php echo e(session()->get('msg')); ?>

                            </div>
                        <?php elseif(session()->has('error')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session()->get('error')); ?>

                            </div>
                        <?php endif; ?>
                        <h6 class="mb-4">Drivers Data</h6>
                        <a href="<?php echo e(route('addDrivers')); ?>" class="btn btn-primary">Add Driver</a>
                        <div class="table-responsive">
                            <table class="table  table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Name</th>
                                        <th scope="col">Email</th>
                                        <th scope="col">Created At</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($driver->id); ?></th>
                                            <td><?php echo e($driver->name); ?></td>
                                            <td><?php echo e($driver->email); ?></td>
                                            <td><?php echo e($driver->created_at); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('editDrivers',['id'=>$driver->id])); ?>"> <i class="fa fa-edit"></i>Edit</a>
                                                |
                                                <a href="<?php echo e(route('deleteUsers',['id'=>$driver->id])); ?>"> <i class="fa fa-trash"></i>Delete</a>
                                                |
                                                <a href="<?php echo e(route('viewUserLogs',['user_id'=>$driver->id])); ?>"> <i class="fa fa-file"></i>View Logs</a>

                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Table End -->



<?php $__env->stopSection(); ?>


<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BookingBackEnd\resources\views/drivers.blade.php ENDPATH**/ ?>