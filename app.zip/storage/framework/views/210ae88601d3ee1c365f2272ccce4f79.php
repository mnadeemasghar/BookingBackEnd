<?php $__env->startSection('content'); ?>


<!-- Content Start -->
<div class="content">
    <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


    <!-- Table Start -->
    <div class="container-fluid pt-4 px-4">
        <div class="row g-4">
            <div class="col-12">
                <div class="bg-secondary rounded h-100 p-4">
                    <h6 class="mb-4">Booking Data</h6>
                    <?php if(isset($for_partner) && $for_partner): ?>
                        <a href="<?php echo e(route('addBooking')); ?>" class="btn btn-primary">Create Booking</a>
                    <?php endif; ?>
                    <div class="table-responsive">
                        <table class="table  table-hover" id="myTable">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Drop Off</th>
                                    <th scope="col">Pick Up</th>
                                    <th scope="col">Pick Date</th>
                                    <th scope="col">Vehicle Type</th>
                                    <th scope="col">Extras</th>
                                    <th scope="col">Driver ID</th>
                                    <th scope="col">Driver Name</th>
                                    <th scope="col">Passengers</th>
                                    <?php if($role == 'Admin' || $role == 'Partner'): ?>
                                    <th scope="col">Price</th>
                                    <th scope="col">Rejection</th>
                                    <?php endif; ?>
                                    <th scope="col">Status</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($booking->booking_id); ?></td>
                                        <td><?php echo e($booking->destination); ?></td>
                                        <td><?php echo e($booking->location); ?></td>
                                        <td><?php echo e($booking->pick_date_time); ?></td>
                                        <td><?php echo e($booking->vehicle_type); ?></td>
                                        <td><?php echo e($booking->extras); ?></td>
                                        <td><?php echo e($booking->driver_id); ?></td>
                                        <td><?php echo e($booking->driver[0]->name ?? ""); ?></td>
                                        <td><?php echo e($booking->passenger_nos); ?></td>
                                        <?php if($role == 'Admin' || $role == 'Partner'): ?>
                                        <td><?php echo e($booking->currency ?? ""); ?> <?php echo e($booking->price ?? ""); ?></td>
                                        <td><?php echo e($booking->reason ?? ""); ?></td>
                                        <?php endif; ?>
                                        <td><?php echo e($booking->status); ?></td>
                                        <td>
                                            <?php if($role == "Partner"): ?>
                                                <a href="<?php echo e(route('viewLogs',['booking_id' => $booking->id])); ?>">
                                                    <i class="fa fa-user"></i>
                                                    Logs
                                                </a>
                                                <br>
                                                <a href="<?php echo e(route('passengers',['booking_id' => $booking->id])); ?>">
                                                    <i class="fa fa-user"></i>
                                                    Passengers
                                                </a>
                                                <br>
                                                <a href="<?php echo e(route('editBooking',['id' => $booking->id])); ?>">
                                                    <i class="fa fa-edit"></i>
                                                    Edit
                                                </a>
                                                <br>
                                                <a href="<?php echo e(route('deleteBooking',['id' => $booking->id])); ?>">
                                                    <i class="fa fa-trash"></i>
                                                    Delete
                                                </a>
                                            <?php elseif($role == "Admin"): ?>
                                                <a href="<?php echo e(route('viewLogs',['booking_id' => $booking->id])); ?>">
                                                    <i class="fa fa-user"></i>
                                                    Logs
                                                </a>
                                                <br>
                                                <a href="<?php echo e(route('passengers',['booking_id' => $booking->id])); ?>">
                                                    <i class="fa fa-user"></i>
                                                    Passengers
                                                </a>
                                                <br>
                                                <a href="<?php echo e(route('editBooking',['id' => $booking->id])); ?>">
                                                    <i class="fa fa-edit"></i>
                                                    Edit
                                                </a>
                                                <br>
                                                <a href="<?php echo e(route('deleteBooking',['id' => $booking->id])); ?>">
                                                    <i class="fa fa-trash"></i>
                                                    Delete
                                                </a>
                                                <br>
                                                <?php if($booking->status == "pending"): ?>
                                                    <a  class="text-success" href="<?php echo e(route('acceptBooking',['id' => $booking->id])); ?>">
                                                        <i class="fa fa-book"></i>
                                                        Aceept
                                                    </a>
                                                    <br>
                                                    <a class="text-danger" href="<?php echo e(route('rejectBooking',['id' => $booking->id])); ?>">
                                                        <i class="fa fa-book"></i>
                                                        Reject
                                                    </a>
                                                    <?php elseif($booking->status == "accepted"): ?>
                                                        <a href="<?php echo e(route('assignDriver',['booking_id' => $booking->id])); ?>">
                                                            <i class="fa fa-plus"></i>
                                                            Assign
                                                        </a>
                                                <?php elseif($booking->status == "assigned"): ?>
                                                    <a href="<?php echo e(route('assignDriver',['booking_id' => $booking->id])); ?>">
                                                        <i class="fa fa-plus"></i>
                                                        Assign
                                                    </a>
                                                <?php endif; ?>
                                            <?php elseif($role == "Driver"): ?>
                                                <a href="<?php echo e(route('viewPassengers',['booking_id' => $booking->id])); ?>">
                                                    <i class="fa fa-user"></i>
                                                    Passengers
                                                </a>
                                                <br>
                                                <?php if($booking->status == "assigned"): ?>
                                                    <a href="<?php echo e(route('onTheWayBooking',['id' => $booking->id])); ?>">
                                                        <i class="fa fa-book"></i>
                                                        On the Way
                                                    </a>
                                                <?php elseif($booking->status == "ontheway"): ?>
                                                    <a href="<?php echo e(route('arriveBooking',['id' => $booking->id])); ?>">
                                                        <i class="fa fa-book"></i>
                                                        Arrived
                                                    </a>
                                                <?php elseif($booking->status == "arrived"): ?>
                                                    <a class="text-success" href="<?php echo e(route('onboardBooking',['id' => $booking->id])); ?>">
                                                        <i class="fa fa-book"></i>
                                                        Onboard
                                                    </a>
                                                    <a class="text-danger" href="<?php echo e(route('noshowBooking',['id' => $booking->id])); ?>">
                                                        <i class="fa fa-book"></i>
                                                        Customer not Shown
                                                    </a>
                                                <?php elseif($booking->status == "onboard"): ?>
                                                    <a href="<?php echo e(route('completeBooking',['id' => $booking->id])); ?>">
                                                        <i class="fa fa-book"></i>
                                                        Complete
                                                    </a>
                                                    <a href="<?php echo e(route('addStopBooking',['id' => $booking->id])); ?>">
                                                        <i class="fa fa-book"></i>
                                                        Stops
                                                    </a>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Table End -->

    <!-- Content End -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BookingBackEnd\resources\views/bookings.blade.php ENDPATH**/ ?>