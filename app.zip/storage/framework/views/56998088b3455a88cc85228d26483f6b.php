<?php $__env->startSection('content'); ?>

    <!-- Content Start -->
    <div class="content">
        <?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <!-- Table Start -->
        <div class="container-fluid pt-4 px-4">
            <div class="row g-4">
                <div class="col-12">
                    <div class="bg-secondary rounded h-100 p-4">
                        <h6 class="mb-4">Vehicle Types</h6>
                        <a href="<?php echo e(route('addVehicle')); ?>" class="btn btn-primary">Add Vehicle</a>
                        <div class="table-responsive">
                            <table class="table  table-hover">
                                <thead>
                                    <tr>
                                        <th scope="col">ID</th>
                                        <th scope="col">Type</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <th scope="row"><?php echo e($vehicle_type->id); ?></th>
                                            <td><?php echo e($vehicle_type->type); ?></td>
                                            <td>
                                                <a href="<?php echo e(route('editVehicle',['id'=>$vehicle_type->id])); ?>"><i class="fa fa-edit"></i>Edit</a>
                                                |
                                                <a href="<?php echo e(route('deleteVehicle',['id'=>$vehicle_type->id])); ?>"><i class="fa fa-trash"></i>Delete</a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Table End -->



<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\BookingBackEnd\resources\views/vehicle_types.blade.php ENDPATH**/ ?>