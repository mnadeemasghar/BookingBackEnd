# Taxi Booking
## How to Install
```
    git clone https://github.com/mnadeemasghar/BookingBackEnd.git
    cd BookingBackEnd
    composer update
    php artisan migrate
    php artisan db::seed
```

### Credentials
Please check console after db::seed command for Dummy credentials of Admin, Drivers and Partners

 